The MNIST dataset can be downloaded from here: https://www.kaggle.com/datasets/hojjatk/mnist-dataset
